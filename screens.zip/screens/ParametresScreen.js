import { colors, typography } from "../theme";
import PropTypes from "prop-types";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import React, { useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  ScrollView,
  Alert,
  SafeAreaView,
} from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { SettingsContext } from "../services/SettingsContext";
import AppButton from "../components/AppButton";
import i18n from "../i18n";

export default function ParametresScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const {
    theme,
    setTheme,
    langue,
    setLangue,
    texteGrand,
    setTexteGrand,
    modeEnfant,
    setModeEnfant,
    contraste,
    setContraste,
  } = useContext(SettingsContext);

  const containerStyle = [
    styles.container,
    contraste && { backgroundColor: colors.contrastBackground },
    { paddingTop: insets.top + 8, paddingBottom: insets.bottom + 8 },
  ];

  const titleStyle = [
    styles.title,
    texteGrand && { fontSize: typography.fontSizeXL },
    contraste && { color: colors.contrastText },
  ];

  const sectionStyle = [
    styles.section,
    contraste && { borderColor: colors.contrastText },
  ];

  const labelStyle = [
    styles.label,
    texteGrand && { fontSize: typography.fontSizeLarge },
    contraste && { color: colors.contrastText },
  ];

  const handleResetSettings = () => {
    Alert.alert(
      "Réinitialiser les paramètres",
      "Êtes-vous sûr de vouloir réinitialiser tous les paramètres ?",
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Réinitialiser",
          style: "destructive",
          onPress: () => {
            setTheme("clair");
            setLangue("fr");
            setTexteGrand(false);
            setModeEnfant(false);
            setContraste(false);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={containerStyle}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={titleStyle}>{i18n.t("settingsTitle")}</Text>

        {/* Thème */}
        <View style={sectionStyle}>
          <Text style={styles.sectionTitle}>{i18n.t("appearance")}</Text>
          <View style={styles.settingRow}>
            <Text style={labelStyle}>{i18n.t("settings")} :</Text>
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[
                  styles.themeButton,
                  theme === "clair" && styles.selectedButton,
                  contraste && styles.contrastButton,
                ]}
                onPress={() => setTheme("clair")}
                accessibilityLabel="Thème clair"
              >
                <MaterialCommunityIcons
                  name="weather-sunny"
                  size={20}
                  color={theme === "clair" ? "#fff" : "#666"}
                />
                <Text
                  style={[
                    styles.buttonText,
                    theme === "clair" && styles.selectedButtonText,
                    contraste && { color: colors.contrastText },
                  ]}
                >
                  {i18n.t("themeLight")}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.themeButton,
                  theme === "sombre" && styles.selectedButton,
                  contraste && styles.contrastButton,
                ]}
                onPress={() => setTheme("sombre")}
                accessibilityLabel="Thème sombre"
              >
                <MaterialCommunityIcons
                  name="weather-night"
                  size={20}
                  color={theme === "sombre" ? "#fff" : "#666"}
                />
                <Text
                  style={[
                    styles.buttonText,
                    theme === "sombre" && styles.selectedButtonText,
                    contraste && { color: colors.contrastText },
                  ]}
                >
                  {i18n.t("themeDark")}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Langue */}
        <View style={sectionStyle}>
          <Text style={styles.sectionTitle}>{i18n.t("language")}</Text>
          <View style={styles.settingRow}>
            <Text style={labelStyle}>{i18n.t("language")}</Text>
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[
                  styles.langButton,
                  langue === "fr" && styles.selectedButton,
                  contraste && styles.contrastButton,
                ]}
                onPress={() => setLangue("fr")}
                accessibilityLabel="Langue française"
              >
                <Text
                  style={[
                    styles.buttonText,
                    langue === "fr" && styles.selectedButtonText,
                    contraste && { color: colors.contrastText },
                  ]}
                >
                  Français
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.langButton,
                  langue === "en" && styles.selectedButton,
                  contraste && styles.contrastButton,
                ]}
                onPress={() => setLangue("en")}
                accessibilityLabel="Langue anglaise"
              >
                <Text
                  style={[
                    styles.buttonText,
                    langue === "en" && styles.selectedButtonText,
                    contraste && { color: colors.contrastText },
                  ]}
                >
                  English
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.langButton,
                  langue === "mg" && styles.selectedButton,
                  contraste && styles.contrastButton,
                ]}
                onPress={() => setLangue("mg")}
                accessibilityLabel="Langue malgache"
              >
                <Text
                  style={[
                    styles.buttonText,
                    langue === "mg" && styles.selectedButtonText,
                    contraste && { color: colors.contrastText },
                  ]}
                >
                  Malagasy
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Accessibilité */}
        <View style={sectionStyle}>
          <Text style={styles.sectionTitle}>{i18n.t("accessibility")}</Text>
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={labelStyle}>{i18n.t("largeText")}</Text>
              <Text style={styles.settingDescription}>
                Augmente la taille du texte pour une meilleure lisibilité
              </Text>
            </View>
            <Switch
              value={texteGrand}
              onValueChange={setTexteGrand}
              trackColor={{ false: "#767577", true: colors.primary }}
              thumbColor={texteGrand ? "#fff" : "#f4f3f4"}
            />
          </View>
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={labelStyle}>{i18n.t("highContrast")}</Text>
              <Text style={styles.settingDescription}>
                Améliore la visibilité avec des couleurs contrastées
              </Text>
            </View>
            <Switch
              value={contraste}
              onValueChange={setContraste}
              trackColor={{ false: "#767577", true: colors.secondary }}
              thumbColor={contraste ? "#fff" : "#f4f3f4"}
            />
          </View>
        </View>

        {/* Mode enfant */}
        <View style={sectionStyle}>
          <Text style={styles.sectionTitle}>{i18n.t("specialMode")}</Text>
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={labelStyle}>{i18n.t("childMode")}</Text>
              <Text style={styles.settingDescription}>
                Interface simplifiée avec moins de catégories
              </Text>
            </View>
            <Switch
              value={modeEnfant}
              onValueChange={setModeEnfant}
              trackColor={{ false: "#767577", true: colors.success }}
              thumbColor={modeEnfant ? "#fff" : "#f4f3f4"}
            />
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actionsSection}>
          <AppButton
            title={i18n.t("testVoices")}
            onPress={() => navigation.navigate("VoiceTest")}
            color="primary"
            contrast={contraste}
            accessibilityLabel="Tester les voix disponibles"
          />
          <AppButton
            title={i18n.t("customMessagesLong")}
            onPress={() => navigation.navigate("CustomMessages")}
            color="secondary"
            contrast={contraste}
            accessibilityLabel="Accéder aux messages personnalisés"
          />
          <AppButton
            title={i18n.t("resetSettings")}
            onPress={handleResetSettings}
            color="error"
            contrast={contraste}
            accessibilityLabel="Réinitialiser tous les paramètres"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

ParametresScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func,
  }),
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: typography.fontSizeXL,
    fontWeight: typography.fontWeightBold,
    color: colors.primary,
    marginBottom: 24,
    marginTop: 16,
    alignSelf: "center",
    fontFamily: typography.fontFamily,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 24,
    padding: 16,
    backgroundColor: colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    elevation: 2,
    shadowColor: colors.primary,
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: typography.fontSizeLarge,
    fontWeight: typography.fontWeightBold,
    color: colors.primary,
    marginBottom: 16,
    fontFamily: typography.fontFamily,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  label: {
    fontSize: typography.fontSizeRegular,
    fontWeight: typography.fontWeightBold,
    color: colors.text,
    marginBottom: 4,
    fontFamily: typography.fontFamily,
  },
  settingDescription: {
    fontSize: 14,
    color: colors.textLight,
    fontFamily: typography.fontFamily,
  },
  buttonGroup: {
    flexDirection: "row",
    gap: 8,
  },
  themeButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f0f0f0",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 80,
    justifyContent: "center",
  },
  langButton: {
    backgroundColor: "#f0f0f0",
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    minWidth: 80,
    alignItems: "center",
  },
  selectedButton: {
    backgroundColor: colors.primary,
  },
  contrastButton: {
    backgroundColor: colors.contrastBackground,
    borderColor: colors.contrastText,
    borderWidth: 1,
  },
  buttonText: {
    fontSize: 14,
    fontWeight: typography.fontWeightBold,
    color: colors.text,
    marginLeft: 4,
    fontFamily: typography.fontFamily,
  },
  selectedButtonText: {
    color: "#fff",
  },
  actionsSection: {
    marginHorizontal: 16,
    marginBottom: 24,
    gap: 12,
  },
});
