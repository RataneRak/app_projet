// Configuration des voix par langue (simulation)
const VOICE_CONFIG = {
  fr: {
    language: "fr-FR",
    pitch: 1.0,
    rate: 0.8,
  },
  en: {
    language: "en-US",
    pitch: 1.0,
    rate: 0.8,
  },
  mg: {
    language: "en-US", // Fallback sur l'anglais pour le malgache
    pitch: 1.0,
    rate: 0.7, // Plus lent pour le malgache
  },
  ar: {
    language: "ar-SA",
    pitch: 1.0,
    rate: 0.8,
  },
  es: {
    language: "es-ES",
    pitch: 1.0,
    rate: 0.8,
  },
};

class VoiceService {
  constructor() {
    this.isSpeaking = false;
    this.currentVoice = null;
  }

  // Parler avec la langue spécifiée (simulation)
  speak(text, language = "fr") {
    if (this.isSpeaking) {
      this.stop();
    }

    const config = VOICE_CONFIG[language] || VOICE_CONFIG.fr;
    this.isSpeaking = true;
    // eslint-disable-next-line no-unused-vars
    const _unused = config;

    // Simulation de la synthèse vocale
    console.log(`[VOIX ${language.toUpperCase()}] ${text}`);

    // Simuler le temps de parole
    setTimeout(() => {
      this.isSpeaking = false;
      this.currentVoice = null;
    }, 2000);
  }

  // Arrêter la synthèse vocale
  stop() {
    if (this.isSpeaking) {
      this.isSpeaking = false;
      this.currentVoice = null;
      console.log("[VOIX] Arrêt de la synthèse vocale");
    }
  }

  // Vérifier si une voix est disponible (version simplifiée)
  async isVoiceAvailable(language = "fr") {
    try {
      const config = VOICE_CONFIG[language];
      return !!config;
    } catch (error) {
      console.error("Erreur lors de la vérification des voix:", error);
      return false;
    }
  }

  // Parler en malgache avec gestion des erreurs
  speakMalagasy(text) {
    // Si pas de voix malgache disponible, utiliser l'anglais comme fallback
    this.speak(text, "mg");
  }

  // Parler avec une voix spécifique (simulation)
  speakWithVoice(text /* , voiceConfig */) {
    if (this.isSpeaking) {
      this.stop();
    }

    this.isSpeaking = true;

    // Simulation de la synthèse vocale
    console.log(`[VOIX PERSONNALISÉE] ${text}`);

    // Simuler le temps de parole
    setTimeout(() => {
      this.isSpeaking = false;
      this.currentVoice = null;
    }, 2000);
  }
}

export default new VoiceService();
