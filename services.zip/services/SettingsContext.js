// /services/SettingsContext.js

import React from "react";

export const SettingsContext = React.createContext();
